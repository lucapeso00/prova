Capitolo 1
==========

In questo capitolo, vengono descritte le funzioni principali ...
